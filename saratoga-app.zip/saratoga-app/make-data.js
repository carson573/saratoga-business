// Builds data.json from the data inside index.html.
// Run after you edit businesses / menus / events:  node make-data.js
const fs=require('fs');
const src=fs.readFileSync(__dirname+'/index.html','utf8');
function grab(name){
  const i=src.indexOf('\nconst '+name+'=');
  if(i<0)throw new Error('missing '+name);
  const rest=src.slice(i+1);
  const m=rest.slice(10).search(/\n(const |function |let |\/\*|document\.|\$\()/);
  const stmt=rest.slice(0,m<0?rest.length:m+10).trim().replace(/;$/,'');
  return stmt;
}
const names=['R','C','dinner','D','S','DP','MENU','CH','EV'];
const code=names.map(grab).join(';\n')+';\nreturn {C,D,S,DP,MENU,EV};';
const {D,MENU,DP,EV}=new Function(code)();
const plain=s=>s.replace(/&amp;/g,'&');
const items=[];
D.forEach(o=>{
  const m=MENU[o.n];
  if(m)m.s.forEach(([t,it])=>it.split(';').forEach(i=>items.push(plain(o.n)+'|'+plain(i.split('|')[0]))));
  else{const x=DP[o.n];if(x&&x.m)x.m.forEach(n=>items.push(plain(o.n)+'|'+plain(n)))}
});
const out={updated:new Date().toISOString().slice(0,10),
  businesses:D.map(o=>plain(o.n)),items,
  events:EV.map(e=>({start:e[0],end:e[1]||e[0],name:plain(e[2]),url:e[6]||''}))};
fs.writeFileSync(__dirname+'/data.json',JSON.stringify(out,null,1));
console.log('businesses',out.businesses.length,'items',items.length,'events',out.events.length);
