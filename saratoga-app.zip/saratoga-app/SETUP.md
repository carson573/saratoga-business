# Saratoga Finder: put it online and turn on phone alerts

Everything here is free. You will use two websites: **GitHub** (hosts the app) and **Cloudflare** (sends the alerts). Part 1 gets you an installable app. Part 2 adds alerts that arrive even when the app is closed. You can stop after Part 1 and the app still works.

Screens on these sites change now and then, so a button may be worded a little differently from what is written here.

---

## Part 1: Put the app online (about 10 minutes)

1. Make a free account at **github.com**.
2. Click **+** (top right) → **New repository**. Name it `saratoga`. Choose **Public**. Click **Create repository**.
3. Click **uploading an existing file**. Open the `saratoga-app` folder on your computer, select everything inside it, and drag it all into the page. Include the `icons` folder and the `worker` folder. Wait for the uploads to finish, then click **Commit changes**.
4. Go to **Settings** → **Pages**. Under **Branch**, pick `main` and `/ (root)`, then click **Save**.
5. After a minute or two, that page shows your link: `https://YOURNAME.github.io/saratoga/`. Open it. This is your app.

**Install it on a phone:**
- **iPhone / iPad** (iOS 16.4 or newer): open the link in **Safari**, tap the **Share** button, then **Add to Home Screen**. Open the app from your home screen.
- **Android**: open the link in Chrome, tap the **⋮** menu, then **Install app**. (Or use the **Install the app** button inside the 🔔 panel.)
- **Computer** (Chrome or Edge): click the install icon at the right end of the address bar.

---

## Part 2: Turn on phone alerts (about 20 minutes)

### A. Make your keys
Open `https://YOURNAME.github.io/saratoga/keys.html` and click **Make my keys**. You get three values: `VAPID_PUBLIC`, `VAPID_PRIVATE` and `ADMIN_KEY`. Leave this tab open. Save them somewhere safe too.

### B. Create the notification server
1. Make a free account at **cloudflare.com**.
2. Go to **Workers & Pages** → **Create** → **Create Worker**. Name it `saratoga-alerts` and click **Deploy**.
3. Click **Edit code**. Delete everything in the editor, then paste in the whole contents of `worker/worker.js` (open it in any text editor, or in your GitHub repository). Click **Deploy**.

### C. Connect storage
1. In Cloudflare go to **Storage & Databases** → **KV** → **Create a namespace**. Name it `saratoga`.
2. Open your Worker → **Settings** → **Bindings** → **Add** → **KV namespace**. Set **Variable name** to exactly `SUBS` and pick the `saratoga` namespace. Save.

### D. Add the keys
Still in the Worker's **Settings** → **Variables and Secrets**, add four, then **Deploy**:

| Name | Value | Type |
|---|---|---|
| `VAPID_PUBLIC` | from keys.html | Text |
| `VAPID_PRIVATE` | from keys.html | **Secret** |
| `ADMIN_KEY` | from keys.html | **Secret** |
| `SITE_URL` | `https://YOURNAME.github.io/saratoga` (no slash at the end) | Text |

### E. Set the schedule
In the Worker → **Settings** → **Trigger Events** → **Cron Triggers** → **Add**, enter `*/30 * * * *` (every 30 minutes) and save.

### F. Tell the app where the server is
1. Copy your Worker's address (it ends in `workers.dev`, shown at the top of the Worker page).
2. In your GitHub repository click `config.js`, then the pencil icon. Paste the address between the quotes, for example `window.SARATOGA_API = "https://saratoga-alerts.yourname.workers.dev";`. Click **Commit changes**.

### G. Try it
1. Open the app (on iPhone, from the home-screen icon). Tap 🔔 → **Turn on phone alerts** → **Allow**.
2. Open `https://YOURNAME.github.io/saratoga/admin.html`, enter the server address and your admin key, type a test message and click **Send to everyone**. It should arrive on your phone within seconds.

---

## What gets sent, and when

| Alert | When |
|---|---|
| Streak reminder | Two hours left and again one hour left in the person's day, only if they read yesterday and have not read today. Uses the time zone of their device. |
| New business, new things to try, new events | Checked once a morning (about 9–10 AM Pacific). It compares `data.json` with what it saw the day before. |
| Event coming up | Once, when an event is within 3 days. |
| Your own announcements | Any time, from `admin.html`. |

## Keeping the app current

The business list, menus and events live inside `index.html`. When they change, ask Claude to update them, then upload the new `index.html` and `data.json` to GitHub (**Add file** → **Upload files**). The next morning's check announces what is new. If you have Node installed you can rebuild `data.json` yourself with `node make-data.js`.

## Good to know

- **Free limits.** A free Cloudflare Worker can reach about 45 people per 30-minute cycle. A bigger audience still gets every announcement, it just trickles out over a few cycles. Past a few hundred people, the Cloudflare paid plan (about $5 a month) removes this.
- **iPhone** only allows alerts for apps added to the Home Screen, on iOS 16.4 or newer.
- **Privacy.** The server keeps each device's alert address, plus the date and length of the person's streak so it can send reminders. Nothing else. **Turn off** in the 🔔 panel removes it.
- **Not on the App Store or Google Play.** People install from your link. Store versions need paid developer accounts and review.
- **Snapshot data.** Menus, hours and events are a snapshot and can go out of date, as noted in the app.
- **Starting over.** If you ever make new keys, everyone must turn alerts on again.
