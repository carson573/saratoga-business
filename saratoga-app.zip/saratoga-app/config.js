// After you set up the notification server (see SETUP.md, Part 2),
// paste its address between the quotes. Example:
//   "https://saratoga-alerts.yourname.workers.dev"
// Leave it empty and the app still installs and works, but phone alerts stay off.
window.SARATOGA_API = "";
