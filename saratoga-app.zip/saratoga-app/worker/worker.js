// Saratoga Finder: notification server (Cloudflare Worker, free plan).
// Paste this whole file into a new Worker. Setup steps are in SETUP.md.
//
// Needs: one KV namespace bound as  SUBS
//        variables:  VAPID_PUBLIC, VAPID_PRIVATE, ADMIN_KEY, SITE_URL
//        optional:   CONTACT  (an email like mailto:you@example.com)
//        cron trigger:  */30 * * * *

const enc = new TextEncoder();
const LIMIT = 48;               // free plan allows 50 outside calls per run; stay under it
const PAGE = 40;                // people handled per KV page
const PUSH_HOSTS = ['fcm.googleapis.com', 'push.services.mozilla.com', 'push.apple.com', 'notify.windows.com'];
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'content-type, authorization',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
};

/* ---------- small helpers ---------- */
const b64u = (buf) => {
  const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = ''; for (const x of b) s += String.fromCharCode(x);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};
const unb64u = (t) => {
  const s = atob((t + '='.repeat((4 - (t.length % 4)) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(s, (c) => c.charCodeAt(0));
};
const cat = (...a) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let i = 0; for (const x of a) { o.set(x, i); i += x.length; } return o; };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json', ...CORS } });
const sha = async (t) => b64u(await crypto.subtle.digest('SHA-256', enc.encode(t))).slice(0, 32);

function okEndpoint(u) {
  try {
    const x = new URL(u);
    return x.protocol === 'https:' && u.length < 900 && PUSH_HOSTS.some((h) => x.hostname === h || x.hostname.endsWith('.' + h));
  } catch (e) { return false; }
}
function same(a, b) { // constant-time-ish string compare
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0;
}
const isAdmin = (req, env) => {
  const h = req.headers.get('authorization') || '';
  return !!env.ADMIN_KEY && env.ADMIN_KEY.length >= 8 && same(h.replace(/^Bearer\s+/i, ''), env.ADMIN_KEY);
};

/* ---------- Web Push: VAPID + message encryption (RFC 8292, RFC 8291) ---------- */
async function vapidKey(env) {
  const pub = unb64u(env.VAPID_PUBLIC);
  return crypto.subtle.importKey('jwk', {
    kty: 'EC', crv: 'P-256', d: env.VAPID_PRIVATE, x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), ext: true,
  }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
}
async function vapidHeader(endpoint, env, now) {
  const key = await vapidKey(env);
  const head = b64u(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const claims = b64u(enc.encode(JSON.stringify({
    aud: new URL(endpoint).origin,
    exp: Math.floor(now / 1000) + 12 * 3600,
    sub: env.CONTACT || env.SITE_URL || 'mailto:admin@example.com',
  })));
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, enc.encode(head + '.' + claims));
  return 'vapid t=' + head + '.' + claims + '.' + b64u(sig) + ', k=' + env.VAPID_PUBLIC;
}
async function hkdf(salt, ikm, info, bytes) {
  const k = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info }, k, bytes * 8));
}
async function encrypt(payload, p256dh, auth) {
  const ua = unb64u(p256dh), authSecret = unb64u(auth);
  const eph = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const asPub = new Uint8Array(await crypto.subtle.exportKey('raw', eph.publicKey));
  const uaKey = await crypto.subtle.importKey('raw', ua, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const secret = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: uaKey }, eph.privateKey, 256));
  const ikm = await hkdf(authSecret, secret, cat(enc.encode('WebPush: info\0'), ua, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode('Content-Encoding: aes128gcm\0'), 16);
  const nonce = await hkdf(salt, ikm, enc.encode('Content-Encoding: nonce\0'), 12);
  const aes = await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']);
  const body = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, aes, cat(payload, new Uint8Array([2]))));
  const rs = new Uint8Array([0, 0, 0x10, 0]); // record size 4096
  return cat(salt, rs, new Uint8Array([asPub.length]), asPub, body);
}
// Returns 'ok', 'dead' (device gone, remove it) or 'fail' (try again another time).
async function push(sub, msg, env, ctx, opts = {}) {
  ctx.used++;
  try {
    const body = await encrypt(enc.encode(JSON.stringify(msg)), sub.keys.p256dh, sub.keys.auth);
    const r = await fetch(sub.endpoint, {
      method: 'POST',
      headers: {
        authorization: await vapidHeader(sub.endpoint, env, ctx.now),
        'content-encoding': 'aes128gcm',
        'content-type': 'application/octet-stream',
        ttl: String(opts.ttl || 3 * 3600),
        urgency: opts.urgency || 'normal',
      },
      body,
    });
    if (r.status === 404 || r.status === 410) return 'dead';
    return r.ok ? 'ok' : 'fail';
  } catch (e) { return 'fail'; }
}

/* ---------- stored people ---------- */
// key  s:<hash of endpoint>   value {sub, st}   metadata {e,k,a,l,r,o}  (so a list needs no extra reads)
async function saveSub(env, sub, st) {
  const id = 's:' + await sha(sub.endpoint);
  const meta = { e: sub.endpoint, k: sub.keys.p256dh, a: sub.keys.auth, l: st.last, r: st.run, o: st.off };
  await env.SUBS.put(id, JSON.stringify({ sub, st }), JSON.stringify(meta).length < 1000 ? { metadata: meta } : { metadata: { l: st.last, r: st.run, o: st.off } });
  return id;
}
function cleanSub(s) {
  if (!s || typeof s.endpoint !== 'string' || !okEndpoint(s.endpoint)) return null;
  const k = s.keys || {};
  if (typeof k.p256dh !== 'string' || typeof k.auth !== 'string' || k.p256dh.length > 120 || k.auth.length > 40) return null;
  return { endpoint: s.endpoint, keys: { p256dh: k.p256dh, auth: k.auth } };
}
function cleanSt(s) {
  s = s || {};
  const last = /^\d{4}-\d\d-\d\d$/.test(s.last || '') ? s.last : null;
  const run = Number.isInteger(s.run) && s.run >= 0 && s.run < 100000 ? s.run : 0;
  const off = Number.isInteger(s.off) && s.off >= -840 && s.off <= 840 ? s.off : 0;
  return { last, run, off };
}
async function subFromKey(env, key, ctx) {
  const m = key.metadata;
  if (m && m.e) return { endpoint: m.e, keys: { p256dh: m.k, auth: m.a } };
  ctx.used++;
  const v = await env.SUBS.get(key.name, 'json');
  return v && v.sub ? v.sub : null;
}

/* ---------- sending to everyone (in chunks, because of the free-plan limit) ---------- */
// job = {msg, c, skip}. Returns {done, sent, job}
async function runJob(env, ctx, job) {
  let sent = 0, c = job.c || undefined, skip = job.skip || 0;
  for (;;) {
    if (ctx.used + 3 > LIMIT) return { done: false, sent, job: { ...job, c, skip } };
    ctx.used++;
    const page = await env.SUBS.list({ prefix: 's:', limit: PAGE, cursor: c });
    const dead = [];
    for (let i = skip; i < page.keys.length; i++) {
      const key = page.keys[i];
      if (ctx.used + (key.metadata && key.metadata.e ? 1 : 2) + 1 > LIMIT) return { done: false, sent, job: { ...job, c, skip: i } };
      const sub = await subFromKey(env, key, ctx);
      if (!sub) { dead.push(key.name); continue; }
      const r = await push(sub, job.msg, env, ctx);
      if (r === 'ok') sent++; else if (r === 'dead') dead.push(key.name);
    }
    for (const d of dead) { if (ctx.used >= LIMIT) break; ctx.used++; await env.SUBS.delete(d); }
    skip = 0;
    if (page.list_complete) return { done: true, sent, job: null };
    c = page.cursor;
  }
}
async function readQueue(env, ctx) { ctx.used++; return (await env.SUBS.get('queue', 'json')) || []; }
async function writeQueue(env, ctx, q) { ctx.used++; if (q.length) await env.SUBS.put('queue', JSON.stringify(q)); else await env.SUBS.delete('queue'); }
async function enqueue(env, ctx, msg, first) {
  const m = { title: String(msg.title || 'Saratoga Finder').slice(0, 80), body: String(msg.body || '').slice(0, 200), url: String(msg.url || './').slice(0, 300), tag: msg.tag ? String(msg.tag).slice(0, 40) : undefined };
  const r = first ? await runJob(env, ctx, { msg: m }) : { done: false, sent: 0, job: { msg: m } };
  if (!r.done) { const q = await readQueue(env, ctx); q.push(r.job); await writeQueue(env, ctx, q.slice(-20)); }
  return r;
}
async function drainQueue(env, ctx) {
  let q = await readQueue(env, ctx);
  if (!q.length) return;
  while (q.length && ctx.used + 4 < LIMIT) {
    const r = await runJob(env, ctx, q[0]);
    if (r.done) q.shift(); else { q[0] = r.job; break; }
  }
  await writeQueue(env, ctx, q);
}

/* ---------- streak reminders ---------- */
const ymd = (d) => d.toISOString().slice(0, 10);
function localOf(off, now) { return new Date(now - off * 60000); } // use the UTC getters on the result
async function streakReminders(env, ctx) {
  let c, left = null;
  for (;;) {
    if (ctx.used + 3 > LIMIT) return;
    ctx.used++;
    const page = await env.SUBS.list({ prefix: 's:', limit: 1000, cursor: c });
    for (const key of page.keys) {
      const m = key.metadata; if (!m || !m.l || !(m.r >= 1)) continue;
      const loc = localOf(m.o || 0, ctx.now), hr = loc.getUTCHours(), mi = loc.getUTCMinutes();
      if ((hr !== 22 && hr !== 23) || mi >= 30) continue;
      if (m.l !== ymd(new Date(loc.getTime() - 864e5))) continue;       // not "read yesterday, not yet today"
      if (ctx.used + 3 > LIMIT) return;
      const sub = await subFromKey(env, key, ctx); if (!sub) continue;
      const hrsLeft = 24 - hr;
      const r = await push(sub, {
        title: hrsLeft + (hrsLeft === 1 ? ' hour' : ' hours') + ' left to ' + (m.r >= 2 ? 'keep your ' + m.r + '-day streak' : 'start your streak'),
        body: 'Read today’s daily pick before midnight.', url: './?pick=1', tag: 'streak',
      }, env, ctx, { ttl: 1800, urgency: 'high' });
      if (r === 'dead' && ctx.used < LIMIT) { ctx.used++; await env.SUBS.delete(key.name); }
    }
    if (page.list_complete) return;
    c = page.cursor;
  }
}

/* ---------- daily check of data.json: new places, new things to try, events ---------- */
const pacific = (now) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Los_Angeles' }).format(new Date(now));
const nice = (s) => new Date(s + 'T12:00:00Z').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
async function dailyCheck(env, ctx) {
  if (!env.SITE_URL) return [];
  ctx.used++;
  const r = await fetch(env.SITE_URL.replace(/\/$/, '') + '/data.json', { cf: { cacheTtl: 0 } });
  if (!r.ok) return [];
  const d = await r.json();
  ctx.used++;
  const snap = await env.SUBS.get('snap', 'json');
  const sentEv = (await env.SUBS.get('evsent', 'json')) || []; ctx.used++;
  const evKey = (e) => e.start + '|' + e.name;
  const today = pacific(ctx.now), in3 = pacific(ctx.now + 3 * 864e5);
  const msgs = [];
  if (snap) {
    const sb = new Set(snap.b), si = new Set(snap.i), se = new Set(snap.e);
    const nb = d.businesses.filter((x) => !sb.has(x));
    if (nb.length) msgs.push({ title: nb.length === 1 ? 'New in Saratoga: ' + nb[0] : nb.length + ' new places in Saratoga', body: nb.length === 1 ? 'Tap to see it on the map.' : nb.slice(0, 4).join(', ') + (nb.length > 4 ? ' and more' : ''), url: './', tag: 'new-biz' });
    const ni = {};
    d.items.filter((x) => !si.has(x)).forEach((x) => { const [b, i] = x.split('|'); if (!nb.includes(b)) (ni[b] = ni[b] || []).push(i); });
    Object.keys(ni).slice(0, 3).forEach((b) => msgs.push({ title: 'New to try at ' + b, body: ni[b].slice(0, 4).join(', ') + (ni[b].length > 4 ? ' and ' + (ni[b].length - 4) + ' more' : ''), url: './', tag: 'new-item-' + b.slice(0, 20) }));
  }
  const fresh = [];
  const soon = d.events.filter((e) => e.end >= today && e.start <= in3 && !sentEv.includes(evKey(e))).slice(0, 3);
  if (snap) {
    const se = new Set(snap.e);
    d.events.filter((e) => !se.has(evKey(e)) && !soon.includes(e)).slice(0, 3).forEach((e) => msgs.push({ title: 'New event: ' + e.name, body: nice(e.start), url: e.url || './', tag: 'new-ev' }));
  }
  soon.forEach((e) => {
    fresh.push(evKey(e));
    msgs.push({ title: (e.start <= today ? 'Happening now: ' : 'Coming up: ') + e.name, body: e.start <= today ? 'On today.' : nice(e.start), url: e.url || './', tag: 'soon' });
  });
  ctx.used++; await env.SUBS.put('snap', JSON.stringify({ b: d.businesses, i: d.items, e: d.events.map(evKey) }));
  if (fresh.length) { ctx.used++; await env.SUBS.put('evsent', JSON.stringify([...sentEv, ...fresh].slice(-200))); }
  return msgs.length > 4 ? [{ title: msgs.length + ' updates in Saratoga', body: 'New places, things to try and events. Tap to see.', url: './', tag: 'digest' }] : msgs;
}

/* ---------- web requests ---------- */
async function handle(req, env) {
  const url = new URL(req.url), p = url.pathname;
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
  const ctx = { used: 0, now: Date.now() };
  try {
    if (p === '/api/key' && req.method === 'GET') return json({ key: env.VAPID_PUBLIC });
    if (p === '/api/subscribe' && req.method === 'POST') {
      const b = await req.json(), sub = cleanSub(b.sub);
      if (!sub) return json({ error: 'bad subscription' }, 400);
      await saveSub(env, sub, cleanSt(b.st));
      return json({ ok: true });
    }
    if (p === '/api/unsubscribe' && req.method === 'POST') {
      const b = await req.json();
      if (typeof b.endpoint === 'string') await env.SUBS.delete('s:' + await sha(b.endpoint));
      return json({ ok: true });
    }
    if (p.startsWith('/api/admin/')) {
      if (!isAdmin(req, env)) return json({ error: 'wrong key' }, 401);
      if (p === '/api/admin/stats') {
        let n = 0, c; for (let i = 0; i < 20; i++) { const pg = await env.SUBS.list({ prefix: 's:', limit: 1000, cursor: c }); n += pg.keys.length; if (pg.list_complete) break; c = pg.cursor; }
        const q = (await env.SUBS.get('queue', 'json')) || [];
        return json({ people: n, waiting: q.length });
      }
      if (p === '/api/admin/send' && req.method === 'POST') {
        const b = await req.json();
        if (!b.title || !b.body) return json({ error: 'need a title and a message' }, 400);
        const r = await enqueue(env, ctx, b, true);
        return json({ sent: r.sent, finished: r.done });
      }
    }
    return json({ ok: true, name: 'Saratoga Finder alerts' });
  } catch (e) { return json({ error: 'server error' }, 500); }
}

export default {
  fetch: handle,
  async scheduled(event, env, _c) {
    const ctx = { used: 0, now: Date.now() };
    const d = new Date(ctx.now);
    await streakReminders(env, ctx);
    if (d.getUTCHours() === 17 && d.getUTCMinutes() < 30) {
      const msgs = await dailyCheck(env, ctx).catch(() => []);
      for (const m of msgs) await enqueue(env, ctx, m, false);
    }
    await drainQueue(env, ctx);
  },
};
